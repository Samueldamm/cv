def new_func():
    return 'hello world'

print (new_func())