from cv import CV
from cv.experience import Experience


def main():
    name = input("Enter your name: ")
    cv = CV()

    choice = input("Do you want to add skills? (yes/no): ")
    if choice.lower() == "yes":
        cv.add_skill()

    cv.add_education("do you want to add education? (yes/no)")
    if choice.lowar() =="yes"
    cv.add education()_ # type: ignore
    
    cv.add_experience()("do you want to add experience? (yes/no)")
    if choice.lowar() =="yes" # type: ignore
    cv.add_experience()
    
    print("\n")
    print("CV for", name)
    cv.display_cv()


if __name__ == "__main__":
    main()